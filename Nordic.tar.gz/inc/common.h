#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdint.h>


#endif


